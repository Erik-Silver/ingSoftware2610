var gis = require('chalk');
console.log("Hola mundo");
console.log(gis.blue.bgRed.bold('Hello world!'));
